"""Library Management System - command-line app (Python 3 + SQLite).

Run:  python library.py
"""
import sqlite3
from datetime import date, timedelta
from pathlib import Path

BASE = Path(__file__).parent
DB_PATH = BASE / "library.db"
LOAN_DAYS = 14


# ---------------- database ----------------
def connect(path=DB_PATH):
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db(conn, with_sample=False):
    conn.executescript((BASE / "sql" / "schema.sql").read_text())
    if with_sample and conn.execute("SELECT COUNT(*) FROM books").fetchone()[0] == 0:
        conn.executescript((BASE / "sql" / "sample_data.sql").read_text())
    conn.commit()


# ---------------- operations ----------------
def add_book(conn, isbn, title, author, publisher, category, copies):
    conn.execute(
        "INSERT INTO books (isbn,title,author,publisher,category,total_copies,available_copies)"
        " VALUES (?,?,?,?,?,?,?)",
        (isbn, title, author, publisher, category, copies, copies),
    )
    conn.commit()


def add_student(conn, reg_no, name, department, year, email, phone):
    conn.execute(
        "INSERT INTO students (reg_no,name,department,year,email,phone) VALUES (?,?,?,?,?,?)",
        (reg_no, name, department, year, email, phone),
    )
    conn.commit()


def _id(conn, table, col, value, idcol):
    row = conn.execute(f"SELECT {idcol} FROM {table} WHERE {col}=?", (value,)).fetchone()
    if not row:
        raise ValueError(f"{table[:-1].title()} '{value}' not found")
    return row[0]


def issue_book(conn, reg_no, isbn, today=None):
    today = today or date.today()
    sid = _id(conn, "students", "reg_no", reg_no, "student_id")
    bid = _id(conn, "books", "isbn", isbn, "book_id")
    due = today + timedelta(days=LOAN_DAYS)
    try:
        conn.execute(
            "INSERT INTO issues (book_id,student_id,issue_date,due_date) VALUES (?,?,?,?)",
            (bid, sid, today.isoformat(), due.isoformat()),
        )
        conn.commit()
    except sqlite3.IntegrityError as e:
        conn.rollback()
        raise ValueError(str(e))
    return due


def return_book(conn, reg_no, isbn, today=None):
    today = today or date.today()
    sid = _id(conn, "students", "reg_no", reg_no, "student_id")
    bid = _id(conn, "books", "isbn", isbn, "book_id")
    row = conn.execute(
        "SELECT issue_id FROM issues WHERE student_id=? AND book_id=? AND return_date IS NULL",
        (sid, bid),
    ).fetchone()
    if not row:
        raise ValueError("No active issue found for this student and book")
    conn.execute("UPDATE issues SET return_date=? WHERE issue_id=?", (today.isoformat(), row[0]))
    conn.commit()
    return conn.execute("SELECT fine_amount FROM issues WHERE issue_id=?", (row[0],)).fetchone()[0]


def search_books(conn, term):
    like = f"%{term}%"
    return conn.execute(
        "SELECT isbn,title,author,category,available_copies,total_copies FROM books"
        " WHERE title LIKE ? OR author LIKE ? OR category LIKE ? ORDER BY title",
        (like, like, like),
    ).fetchall()


def list_students(conn):
    return conn.execute("SELECT reg_no,name,department,year,email FROM students ORDER BY reg_no").fetchall()


def current_issues(conn):
    return conn.execute("SELECT * FROM v_current_issues ORDER BY due_date").fetchall()


def overdue(conn):
    return conn.execute("SELECT * FROM v_current_issues WHERE days_overdue>0 ORDER BY days_overdue DESC").fetchall()


def student_history(conn, reg_no):
    return conn.execute(
        "SELECT b.title,i.issue_date,i.due_date,i.return_date,i.fine_amount FROM issues i"
        " JOIN books b ON b.book_id=i.book_id JOIN students s ON s.student_id=i.student_id"
        " WHERE s.reg_no=? ORDER BY i.issue_date DESC",
        (reg_no,),
    ).fetchall()


# ---------------- CLI ----------------
def show(rows):
    if not rows:
        print("  (no records)")
        return
    for r in rows:
        print("  " + " | ".join(str(r[k]) for k in r.keys()))


MENU = """
===== LIBRARY MANAGEMENT SYSTEM =====
1. Add book            6. Search books
2. Add student         7. List students
3. Issue book          8. Currently issued books
4. Return book         9. Overdue books
5. Student history     0. Exit
"""


def main():
    conn = connect()
    init_db(conn, with_sample=True)
    while True:
        print(MENU)
        choice = input("Choose: ").strip()
        try:
            if choice == "1":
                add_book(conn, input("ISBN: "), input("Title: "), input("Author: "),
                         input("Publisher: "), input("Category: "), int(input("Copies: ")))
                print("Book added.")
            elif choice == "2":
                add_student(conn, input("Reg no: "), input("Name: "), input("Department: "),
                            int(input("Year (1-4): ")), input("Email: "), input("Phone: "))
                print("Student added.")
            elif choice == "3":
                due = issue_book(conn, input("Student reg no: "), input("Book ISBN: "))
                print(f"Issued. Due on {due}.")
            elif choice == "4":
                fine = return_book(conn, input("Student reg no: "), input("Book ISBN: "))
                print(f"Returned. Fine: Rs {fine:.2f}")
            elif choice == "5":
                show(student_history(conn, input("Student reg no: ")))
            elif choice == "6":
                show(search_books(conn, input("Search term: ")))
            elif choice == "7":
                show(list_students(conn))
            elif choice == "8":
                show(current_issues(conn))
            elif choice == "9":
                show(overdue(conn))
            elif choice == "0":
                break
            else:
                print("Invalid choice.")
        except (ValueError, sqlite3.IntegrityError) as e:
            print("Error:", e)


if __name__ == "__main__":
    main()
