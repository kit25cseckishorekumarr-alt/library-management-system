-- Library Management System : schema (SQLite)
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS students (
    student_id  INTEGER PRIMARY KEY AUTOINCREMENT,
    reg_no      TEXT NOT NULL UNIQUE,
    name        TEXT NOT NULL,
    department  TEXT NOT NULL,
    year        INTEGER NOT NULL CHECK (year BETWEEN 1 AND 4),
    email       TEXT UNIQUE,
    phone       TEXT,
    joined_on   TEXT NOT NULL DEFAULT (date('now'))
);

CREATE TABLE IF NOT EXISTS books (
    book_id          INTEGER PRIMARY KEY AUTOINCREMENT,
    isbn             TEXT NOT NULL UNIQUE,
    title            TEXT NOT NULL,
    author           TEXT NOT NULL,
    publisher        TEXT,
    category         TEXT NOT NULL,
    total_copies     INTEGER NOT NULL CHECK (total_copies >= 0),
    available_copies INTEGER NOT NULL CHECK (available_copies >= 0),
    CHECK (available_copies <= total_copies)
);

CREATE TABLE IF NOT EXISTS issues (
    issue_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id     INTEGER NOT NULL REFERENCES books(book_id)       ON DELETE RESTRICT,
    student_id  INTEGER NOT NULL REFERENCES students(student_id) ON DELETE RESTRICT,
    issue_date  TEXT NOT NULL DEFAULT (date('now')),
    due_date    TEXT NOT NULL,
    return_date TEXT,
    fine_amount REAL NOT NULL DEFAULT 0 CHECK (fine_amount >= 0)
);

CREATE INDEX IF NOT EXISTS idx_issues_student ON issues(student_id);
CREATE INDEX IF NOT EXISTS idx_issues_book    ON issues(book_id);
CREATE INDEX IF NOT EXISTS idx_books_title    ON books(title);

-- ---------- Business rules as triggers ----------

-- Rule 1: cannot issue a book with no copies left
CREATE TRIGGER IF NOT EXISTS trg_issue_check_stock
BEFORE INSERT ON issues
WHEN (SELECT available_copies FROM books WHERE book_id = NEW.book_id) <= 0
BEGIN
    SELECT RAISE(ABORT, 'No copies of this book are available');
END;

-- Rule 2: a student can hold at most 3 books at a time
CREATE TRIGGER IF NOT EXISTS trg_issue_check_limit
BEFORE INSERT ON issues
WHEN (SELECT COUNT(*) FROM issues
      WHERE student_id = NEW.student_id AND return_date IS NULL) >= 3
BEGIN
    SELECT RAISE(ABORT, 'Borrowing limit reached (max 3 books)');
END;

-- Rule 3: same student cannot hold two copies of the same title
CREATE TRIGGER IF NOT EXISTS trg_issue_check_duplicate
BEFORE INSERT ON issues
WHEN EXISTS (SELECT 1 FROM issues
             WHERE student_id = NEW.student_id
               AND book_id = NEW.book_id AND return_date IS NULL)
BEGIN
    SELECT RAISE(ABORT, 'Student already has this book issued');
END;

-- Rule 4: issuing reduces available copies
CREATE TRIGGER IF NOT EXISTS trg_issue_decrement
AFTER INSERT ON issues
BEGIN
    UPDATE books SET available_copies = available_copies - 1
    WHERE book_id = NEW.book_id;
END;

-- Rule 5: returning restores stock and computes fine (Rs 2 per late day)
CREATE TRIGGER IF NOT EXISTS trg_return_update
AFTER UPDATE OF return_date ON issues
WHEN OLD.return_date IS NULL AND NEW.return_date IS NOT NULL
BEGIN
    UPDATE books SET available_copies = available_copies + 1
    WHERE book_id = NEW.book_id;

    UPDATE issues
    SET fine_amount = MAX(0, CAST(julianday(NEW.return_date) - julianday(NEW.due_date) AS INTEGER)) * 2
    WHERE issue_id = NEW.issue_id;
END;

-- ---------- Views ----------
CREATE VIEW IF NOT EXISTS v_current_issues AS
SELECT i.issue_id, s.reg_no, s.name AS student, b.title, i.issue_date, i.due_date,
       CASE WHEN date('now') > i.due_date
            THEN CAST(julianday('now') - julianday(i.due_date) AS INTEGER) ELSE 0 END AS days_overdue
FROM issues i
JOIN students s ON s.student_id = i.student_id
JOIN books    b ON b.book_id    = i.book_id
WHERE i.return_date IS NULL;
