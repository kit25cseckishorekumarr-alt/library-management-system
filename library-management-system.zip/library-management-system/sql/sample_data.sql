INSERT INTO students (reg_no, name, department, year, email, phone) VALUES
('21CS001','Arun Prakash','CSE',3,'arun@example.com','9000000001'),
('21CS002','Divya Lakshmi','CSE',3,'divya@example.com','9000000002'),
('21IT014','Karthik Raj','IT',2,'karthik@example.com','9000000003'),
('21EC027','Meena Devi','ECE',4,'meena@example.com','9000000004'),
('21ME033','Suresh Babu','MECH',1,'suresh@example.com','9000000005');

INSERT INTO books (isbn, title, author, publisher, category, total_copies, available_copies) VALUES
('9780073523323','Database System Concepts','Silberschatz, Korth, Sudarshan','McGraw Hill','Database',4,4),
('9780133970777','Fundamentals of Database Systems','Elmasri, Navathe','Pearson','Database',3,3),
('9781119800361','Operating System Concepts','Silberschatz, Galvin, Gagne','Wiley','Operating Systems',3,3),
('9780136042594','Artificial Intelligence: A Modern Approach','Russell, Norvig','Pearson','AI',2,2),
('9780262033848','Introduction to Algorithms','Cormen et al.','MIT Press','Algorithms',2,2),
('9780134093413','Computer Networks','Tanenbaum, Wetherall','Pearson','Networking',2,2);
