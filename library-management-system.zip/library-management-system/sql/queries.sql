-- Useful report queries (run in sqlite3 library.db)

-- 1. Books currently available
SELECT title, author, available_copies FROM books WHERE available_copies > 0 ORDER BY title;

-- 2. Books currently issued, with student
SELECT * FROM v_current_issues;

-- 3. Overdue books
SELECT * FROM v_current_issues WHERE days_overdue > 0 ORDER BY days_overdue DESC;

-- 4. Issue history of a student
SELECT b.title, i.issue_date, i.due_date, i.return_date, i.fine_amount
FROM issues i JOIN books b ON b.book_id = i.book_id
JOIN students s ON s.student_id = i.student_id
WHERE s.reg_no = '21CS001' ORDER BY i.issue_date DESC;

-- 5. Most borrowed books
SELECT b.title, COUNT(*) AS times_issued
FROM issues i JOIN books b ON b.book_id = i.book_id
GROUP BY b.book_id ORDER BY times_issued DESC LIMIT 5;

-- 6. Most active students
SELECT s.name, COUNT(*) AS books_borrowed
FROM issues i JOIN students s ON s.student_id = i.student_id
GROUP BY s.student_id ORDER BY books_borrowed DESC;

-- 7. Total fine collected per department
SELECT s.department, SUM(i.fine_amount) AS total_fine
FROM issues i JOIN students s ON s.student_id = i.student_id
GROUP BY s.department;

-- 8. Category-wise stock
SELECT category, SUM(total_copies) AS total, SUM(available_copies) AS available
FROM books GROUP BY category;

-- 9. Students who never borrowed a book
SELECT name FROM students WHERE student_id NOT IN (SELECT student_id FROM issues);
