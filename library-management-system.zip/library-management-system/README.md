# 📚 Library Management System

A DBMS course (AAT) project that manages **books**, **student records**, and **book issue / return** using a normalized relational schema in SQLite, with business rules enforced by database triggers and a Python command-line interface.

## Features
- Add and search books (by title, author or category)
- Register and list students
- Issue books (14-day loan period)
- Return books with **automatic fine calculation** (₹2 per late day)
- View currently issued and overdue books
- Per-student borrowing history
- Report queries (most borrowed books, fines by department, stock by category)

## Business rules (enforced in the database)
| Rule | Mechanism |
|------|-----------|
| Cannot issue a book with zero copies left | `BEFORE INSERT` trigger |
| Maximum 3 active books per student | `BEFORE INSERT` trigger |
| No duplicate active issue of the same book by one student | `BEFORE INSERT` trigger |
| Issuing decrements, returning increments `available_copies` | `AFTER INSERT / UPDATE` triggers |
| Fine = ₹2 × days late, set on return | `AFTER UPDATE` trigger |
| `available_copies` stays between 0 and `total_copies` | `CHECK` constraints |

## ER Diagram
```mermaid
erDiagram
    STUDENTS ||--o{ ISSUES : borrows
    BOOKS    ||--o{ ISSUES : "is issued in"
    STUDENTS {
        int student_id PK
        text reg_no UK
        text name
        text department
        int year
        text email UK
        text phone
        text joined_on
    }
    BOOKS {
        int book_id PK
        text isbn UK
        text title
        text author
        text publisher
        text category
        int total_copies
        int available_copies
    }
    ISSUES {
        int issue_id PK
        int book_id FK
        int student_id FK
        text issue_date
        text due_date
        text return_date
        real fine_amount
    }
```

## Relational schema
- `students(student_id PK, reg_no UNIQUE, name, department, year, email UNIQUE, phone, joined_on)`
- `books(book_id PK, isbn UNIQUE, title, author, publisher, category, total_copies, available_copies)`
- `issues(issue_id PK, book_id FK → books, student_id FK → students, issue_date, due_date, return_date, fine_amount)`

**Normalization:** the design is in 3NF. Student details and book details live in their own tables; `issues` is the resolving table for the many-to-many relationship between students and books and stores only facts about each transaction.

## Project structure
```
library-management-system/
├── library.py          # CLI application + operations
├── sql/
│   ├── schema.sql      # tables, constraints, triggers, view
│   ├── sample_data.sql # demo students and books
│   └── queries.sql     # report queries
├── tests/test_library.py
├── requirements.txt
└── README.md
```

## Getting started
Requires Python 3.8+ (SQLite is built in).

```bash
git clone https://github.com/<your-username>/library-management-system.git
cd library-management-system
python library.py
```
The database `library.db` is created automatically with sample data on first run.

Run the tests:
```bash
pip install -r requirements.txt
pytest
```

Run report queries directly:
```bash
sqlite3 library.db < sql/queries.sql
```

## Sample session
```
Choose: 3
Student reg no: 21CS001
Book ISBN: 9780073523323
Issued. Due on 2026-11-24.

Choose: 4
Student reg no: 21CS001
Book ISBN: 9780073523323
Returned. Fine: Rs 0.00
```

## Future enhancements
- Web interface (Flask) and login for librarian / student roles
- Book reservation queue and email reminders
- Barcode scanning for ISBN entry

## Author
**Kishore Kumar** — DBMS AAT Project
