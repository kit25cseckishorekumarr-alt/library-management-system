import sqlite3, sys
from datetime import date, timedelta
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import library as lib
import pytest


@pytest.fixture
def conn():
    c = lib.connect(":memory:")
    lib.init_db(c, with_sample=True)
    return c


def stock(c, isbn):
    return c.execute("SELECT available_copies FROM books WHERE isbn=?", (isbn,)).fetchone()[0]


def test_issue_reduces_stock(conn):
    lib.issue_book(conn, "21CS001", "9780073523323")
    assert stock(conn, "9780073523323") == 3


def test_return_restores_stock_no_fine(conn):
    lib.issue_book(conn, "21CS001", "9780073523323")
    assert lib.return_book(conn, "21CS001", "9780073523323") == 0
    assert stock(conn, "9780073523323") == 4


def test_late_return_fine(conn):
    start = date.today() - timedelta(days=20)
    lib.issue_book(conn, "21CS001", "9780073523323", today=start)  # due 6 days ago
    assert lib.return_book(conn, "21CS001", "9780073523323") == 12.0


def test_no_stock_blocked(conn):
    lib.issue_book(conn, "21CS001", "9780262033848")
    lib.issue_book(conn, "21CS002", "9780262033848")
    with pytest.raises(ValueError):
        lib.issue_book(conn, "21IT014", "9780262033848")


def test_borrow_limit(conn):
    for isbn in ("9780073523323", "9780133970777", "9781119800361"):
        lib.issue_book(conn, "21CS001", isbn)
    with pytest.raises(ValueError):
        lib.issue_book(conn, "21CS001", "9780134093413")


def test_duplicate_issue_blocked(conn):
    lib.issue_book(conn, "21CS001", "9780073523323")
    with pytest.raises(ValueError):
        lib.issue_book(conn, "21CS001", "9780073523323")


def test_overdue_listed(conn):
    lib.issue_book(conn, "21CS001", "9780073523323", today=date.today() - timedelta(days=30))
    assert len(lib.overdue(conn)) == 1
